java -jar Gyromite.jar
